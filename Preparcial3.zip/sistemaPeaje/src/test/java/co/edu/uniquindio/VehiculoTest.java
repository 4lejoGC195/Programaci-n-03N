package co.edu.uniquindio;

import static org.junit.jupiter.api.Assertions.*;


import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class VehiculoTest {

    @Test
    public void testPlacaYContadorPeajes() {
        Carro carro = new Carro("AAA123", false, false);

        assertEquals("AAA123", carro.getPlaca());
        assertEquals(0, carro.getNumeroPeajesPagados());

        carro.incrementarPeaje();
        carro.incrementarPeaje();

        assertEquals(2, carro.getNumeroPeajesPagados());
    }

    @Test
    public void testDescripcionDeVehiculo() {
        Moto moto = new Moto("MOTO77", 300);
        String descripcion = moto.getDescripcion();

        assertTrue(descripcion.contains("Moto"));
        assertTrue(descripcion.contains("MOTO77"));
        assertTrue(descripcion.contains("300"));
    }

    @Test
    public void testCalculoPeajeCamionNormal() {
        Camion camion = new Camion("TRUCK9", 3, 9.0);
        assertEquals(21000, camion.calcularPeaje());
    }

    @Test
    public void testCalculoPeajeCamionAltoTonelaje() {
        Camion camion = new Camion("TRUCK10", 2, 12.0);
        assertEquals(15400, camion.calcularPeaje()); // 2 * 7000 = 14000 * 1.10 = 15400
    }
}
