package co.edu.uniquindio;



import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;

public class RegistroPeajeTest {

    @Test
    public void testRegistroPeajeCarroElectrico() {
        Peaje peaje = new Peaje("Peaje Armenia", "Quindío");
        Carro carro = new Carro("ABC123", true, false); // eléctrico

        peaje.calcularPeajeYRegistrar(carro);

        assertEquals(8000, peaje.getTotalRecaudado());
        assertEquals(1, peaje.getRegistros().size());
    }

    @Test
    public void testCamionAltoTonelaje() {
        Camion camion = new Camion("TRK789", 3, 12.0); // más de 10 toneladas
        assertEquals(23100, camion.calcularPeaje()); // 3 * 7000 * 1.10
    }

    @Test
    public void testConductorTotalPago() {
        Conductor conductor = new Conductor("Ana", "Ramirez", "456", LocalDate.of(1985, 6, 15));
        Moto moto = new Moto("MOT123", 150);
        Carro carro = new Carro("CAR456", false, true); // servicio público

        conductor.asignarVehiculo(moto);
        conductor.asignarVehiculo(carro);

        double esperado = moto.calcularPeaje() + carro.calcularPeaje();
        assertEquals(esperado, conductor.calcularTotalPagado());
    }

    @Test
    public void testFiltrarVehiculosPorTipo() {
        Conductor conductor = new Conductor("Pedro", "López", "789", LocalDate.of(2000, 1, 1));
        conductor.asignarVehiculo(new Moto("MT001", 125));
        conductor.asignarVehiculo(new Carro("CR001", false, false));
        conductor.asignarVehiculo(new Moto("MT002", 300));

        assertEquals(2, conductor.getVehiculosPorTipo("Moto").size());
        assertEquals(1, conductor.getVehiculosPorTipo("Carro").size());
    }

    @Test
    public void testTieneCamionDeAltoTonelaje() {
        Conductor conductor = new Conductor("Luis", "Martínez", "999", LocalDate.of(1995, 3, 10));
        conductor.asignarVehiculo(new Camion("CAM999", 2, 12.0));
        assertTrue(conductor.tieneCamionDeAltoTonelaje());
    }
}
