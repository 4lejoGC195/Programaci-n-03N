package co.edu.uniquindio;

public abstract class Vehiculo {
    protected String placa;
    protected int numeroPeajesPagados;

    public Vehiculo(String placa) {
        this.placa = placa;
    }

    public abstract double calcularPeaje();
    public abstract String getDescripcion();

    public String getPlaca() {
        return placa;
    }

    public int getNumeroPeajesPagados() {
        return numeroPeajesPagados;
    }

    public void incrementarPeaje() {
        numeroPeajesPagados++;
    }
}
