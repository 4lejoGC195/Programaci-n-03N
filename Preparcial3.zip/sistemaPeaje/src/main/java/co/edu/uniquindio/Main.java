package co.edu.uniquindio;


import java.time.LocalDate;



import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        // Crear un peaje
        Peaje peaje = new Peaje("Peaje La Línea", "Quindío");

        // Crear un conductor
        Conductor conductor = new Conductor("Juan", "Pérez", "123456789", LocalDate.of(1990, 5, 20));

        // Crear vehículos
        Carro carro = new Carro("ABC123", true, false); // eléctrico
        Moto moto = new Moto("XYZ987", 250); // cilindraje alto
        Camion camion = new Camion("TRK456", 4, 12.5); // carga > 10 toneladas

        // Asignar vehículos al conductor
        conductor.asignarVehiculo(carro);
        conductor.asignarVehiculo(moto);
        conductor.asignarVehiculo(camion);

        // Registrar vehículos en el peaje
        for (Vehiculo vehiculo : conductor.getVehiculos()) {
            peaje.calcularPeajeYRegistrar(vehiculo);
        }

        // Imprimir informe
        peaje.imprimirListadoVehiculos();

        // Consultar total pagado por el conductor
        System.out.println("Total pagado por " + conductor.getNombreCompleto() + ": $" + conductor.calcularTotalPagado());

        // Verificar si tiene camión de alto tonelaje
        if (conductor.tieneCamionDeAltoTonelaje()) {
            System.out.println("Este conductor tiene al menos un camión con más de 10 toneladas.");
        }
    }
}
