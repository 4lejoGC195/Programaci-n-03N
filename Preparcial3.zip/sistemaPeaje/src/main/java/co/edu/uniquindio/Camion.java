
package co.edu.uniquindio;

public class Camion extends Vehiculo {

    private int numeroEjes;
    private double capacidadCargaToneladas;

    public Camion(String placa, int numeroEjes, double capacidadCargaToneladas) {
        super(placa);
        this.numeroEjes = numeroEjes;
        this.capacidadCargaToneladas = capacidadCargaToneladas;
    }

    @Override
    public double calcularPeaje() {
        double base = numeroEjes * 7000;
        if (capacidadCargaToneladas > 10) {
            base *= 1.10;
        }
        return base;
    }

    @Override
    public String getDescripcion() {
        return "Camion - Placa: " + placa + " - Ejes: " + numeroEjes + " - Carga: " + capacidadCargaToneladas + "t";
    }

    public double getCapacidadCargaToneladas() {
        return capacidadCargaToneladas;
    }
}
