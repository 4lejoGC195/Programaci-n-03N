
package co.edu.uniquindio;

import java.util.ArrayList;
import java.util.List;

public class Peaje {

    private String nombre;
    private String departamento;
    private double totalRecaudado;
    private List<RegistroPeaje> registros = new ArrayList<>();

    public Peaje(String nombre, String departamento) {
        this.nombre = nombre;
        this.departamento = departamento;
    }

    public void calcularPeajeYRegistrar(Vehiculo v) {
        double valor = v.calcularPeaje();
        totalRecaudado += valor;
        v.incrementarPeaje();
        registros.add(new RegistroPeaje(v, v.getClass().getSimpleName(), valor));
    }

    public void imprimirListadoVehiculos() {
        System.out.println("Listado de Vehiculos en Peaje: " + nombre);
        for (RegistroPeaje r : registros) {
            System.out.println(r.getVehiculo().getDescripcion() + " - Valor pagado: $" + r.getValorPagado());
        }
        System.out.println("Total Recaudado: $" + totalRecaudado);
    }

    public double getTotalRecaudado() {
        return totalRecaudado;
    }

    public List<RegistroPeaje> getRegistros() {
        return registros;
    }
}
