package co.edu.uniquindio;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Conductor extends Persona {

    private List<Vehiculo> vehiculos = new ArrayList<>();

    public Conductor(String nombre, String apellidos, String documento, LocalDate fechaNacimiento) {
        super(nombre, apellidos, documento, fechaNacimiento);
    }

    public void asignarVehiculo(Vehiculo v) {
        vehiculos.add(v);
    }

    public List<Vehiculo> getVehiculosPorTipo(String tipo) {
        return vehiculos.stream()
                .filter(v -> v.getClass().getSimpleName().equalsIgnoreCase(tipo))
                .collect(Collectors.toList());
    }

    public double calcularTotalPagado() {
        return vehiculos.stream().mapToDouble(Vehiculo::calcularPeaje).sum();
    }

    public boolean tieneCamionDeAltoTonelaje() {
        return vehiculos.stream()
                .filter(v -> v instanceof Camion)
                .map(v -> (Camion)v)
                .anyMatch(c -> c.getCapacidadCargaToneladas() > 10);
    }

    public List<Vehiculo> getVehiculos() {
        return vehiculos;
    }
}
