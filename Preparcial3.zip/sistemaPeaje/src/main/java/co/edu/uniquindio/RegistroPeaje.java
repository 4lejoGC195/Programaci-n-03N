package co.edu.uniquindio;

public class RegistroPeaje {

    private Vehiculo vehiculo;
    private String tipoVehiculo;
    private double valorPagado;

    public RegistroPeaje(Vehiculo vehiculo, String tipoVehiculo, double valorPagado) {
        this.vehiculo = vehiculo;
        this.tipoVehiculo = tipoVehiculo;
        this.valorPagado = valorPagado;
    }

    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public String getTipoVehiculo() {
        return tipoVehiculo;
    }

    public double getValorPagado() {
        return valorPagado;
    }
}
